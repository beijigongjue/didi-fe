/**
 * 单例模式
 */
var Singleton = function() {
	var _instance = null;

	function init() {
		return {
			pubMethod: function() {
				console.log("pubMethod");
			}
		};
	}
	return {
		instance: function() {
			if (!_instance) {
				_instance = init();
			}
			return _instance;
		}
	};
}();

//Singleton匿名自执行，执行完之后返回object
//object内有属性instance，执行instance()返回对象
//console.log(Object.prototype.toString.call(Singleton, null)); //[object Object]
var s1 = Singleton.instance(),
	s2 = Singleton.instance();
console.log(s1 === s2); //true