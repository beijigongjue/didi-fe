/**
 * 单例模式
 */
var singleton = (function() {
	var _instance = null;
	return function() {
		return _instance || (_instance = {
			getXhr: function() {
				console.log("create an xmlhttprequest.");
			},
			isGet: true
		});
	};
})();

var s1 = singleton();
var s2 = singleton();
console.log(s1 === s2);
console.log(s1.getXhr === s2.getXhr);
console.log(s1 === _instance); //语法错误