/**
 * 单例模式－－包装盒
 * @param  {Function} fn [description]
 * @return {[type]}      [description]
 */
var singleton = function(fn) {
	var _instance = null;
	return function() {
		return _instance || (_instance = fn.apply(this, arguments));
	};
};

var Obj = singleton(function() {
	return new Object();
});


var x1 = new Obj();
var x2 = new Obj();
console.log(x2 === x2);